export class CommentRequest {
  content: string;
  constructor(content: string) {
    this.content = content;
  }
}

export class CommentResponse {
  id: string;
  content: string;
  label: string;

  constructor(id: string, content: string, label: string) {
    this.id = id;
    this.content = content;
    this.label = label;
  }
}

