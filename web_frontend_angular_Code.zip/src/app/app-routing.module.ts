

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; // CLI imports router
import { PageNotFoundComponent } from './page-not-found.component';
import { AppComponent } from './app.component';
import { CommentComponent } from './components/comment/comment.component';

const routes: Routes = [
{ path: '',
component: CommentComponent
},
{ path: 'dashboard',
component: CommentComponent
},
{ path: 'comment',
component: CommentComponent
},
{
path: '**',
component: PageNotFoundComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
