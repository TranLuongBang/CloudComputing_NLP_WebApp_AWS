import { Component, OnInit } from '@angular/core';
import { NgForm, FormBuilder, FormGroup } from '@angular/forms';
import { CommentRequest, CommentResponse } from 'src/app/model/comment';
import { CommentService } from '../../service/comment.service';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private commentService: CommentService) { }

  commentResponse: CommentResponse[];
  addForm: FormGroup;
  commentRequest: CommentRequest;

  ngOnInit(): void {
    this.commentService.getComment()
    .subscribe(data => {
      this.commentResponse = data;
    });

    this.addForm = this.formBuilder.group({
      content: ['']
    });
  }

  onSubmit() {
    console.log(this.addForm.value);
    this.commentService.classifyComment(this.addForm.value)
      .subscribe(data => {
        // this.ngOnInit();
        this.commentResponse = data;
        // this.showToaster('Add new area successfully');
        this.addForm.reset();
        // this.closebuttonAdd.nativeElement.click();
      });
  }

}
