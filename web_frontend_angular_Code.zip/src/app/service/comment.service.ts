import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CommentRequest, CommentResponse } from '../model/comment';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  constructor(private http: HttpClient) {}
  baseUrl = 'https://5eef05bzy6.execute-api.us-east-1.amazonaws.com/api/';


  getComment(): Observable<CommentResponse[]> {
    return this.http.get<CommentResponse[]>(this.baseUrl + 'fooGet');
  }

  classifyComment(comment: CommentRequest): Observable<CommentResponse[]> {
    return this.http.post<CommentResponse[]>(this.baseUrl + 'foo', comment);
  }

}
