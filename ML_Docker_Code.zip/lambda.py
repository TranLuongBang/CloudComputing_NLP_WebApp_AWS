
from tensorflow.keras.utils import to_categorical
#import sagemaker
import pandas as pd
import os
import numpy as np
import tensorflow as tf
from tensorflow.python.util.compat import as_str_any
import tensorflow_hub as hub

# from keras.utils import np_utils
import official.nlp.bert.bert_models
import official.nlp.bert.configs
import official.nlp.bert.run_classifier
import official.nlp.bert.tokenization as tokenization
from official.modeling import tf_utils
from official import nlp
from official.nlp import bert
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import numpy as np


def encode_names(n, tokenizer):
    tokens = list(tokenizer.tokenize(n))
    tokens.append('[SEP]')
    return tokenizer.convert_tokens_to_ids(tokens)

def bert_encode(string_list,
                tokenizer, 
                new_feature,  # [NEW]
                new_feature_class_count,  # [NEW] 
                max_seq_length):  
    num_examples = len(string_list)

    string_tokens = tf.ragged.constant([
      encode_names(n, tokenizer) for n in np.array(string_list)])

    cls = [tokenizer.convert_tokens_to_ids(['[CLS]'])]*string_tokens.shape[0]
    input_word_ids = tf.concat([cls, string_tokens], axis=-1)

    input_mask = tf.ones_like(input_word_ids).to_tensor(shape=(None, max_seq_length))

    type_cls = tf.zeros_like(cls)
    type_tokens = tf.ones_like(string_tokens)
    input_type_ids = tf.concat(
      [type_cls, type_tokens], axis=-1).to_tensor(shape=(None, max_seq_length))
    feature = tf.ragged.constant(new_feature).to_tensor(shape=(None, new_feature_class_count))  # [NEW]

    inputs = {
      'input_word_ids': input_word_ids.to_tensor(shape=(None, max_seq_length)),
      'input_mask': input_mask,
      'input_type_ids': input_type_ids,
      'additional_feature': feature}  # [NEW]

    return inputs


#:
def handler(event, context):
  enc_path = r"./Model/twitter_classes.npy"
  fe_path = r"./Model/twitter_wkd.npy"
  vocab_path = r"./Model/twitter_BERT_wWKD/assets/vocab.txt"
  model_location = r'./Model/twitter_BERT_wWKD'
  encoder = LabelEncoder()
  encoder.classes_ =np.load(enc_path)
  featureEncoderSaved = LabelEncoder()
  featureEncoderSaved.classes_ = np.load(fe_path, allow_pickle=True)

  tokenizerSaved = bert.tokenization.FullTokenizer(
      vocab_file=vocab_path,
      do_lower_case=False)

  new_model = tf.keras.models.load_model(model_location)

  # tweet = ["I am not happy for you"]
  wkd = ['Sun']

  tweet = [event['content']]

  dummy_wkd = to_categorical(featureEncoderSaved.transform(np.array(wkd)))  # encodes weekday

  inputs = bert_encode(string_list=list(tweet),
                        tokenizer=tokenizerSaved,
                        new_feature=dummy_wkd,
                        new_feature_class_count=7,
                        max_seq_length=240)

  prediction = new_model.predict(inputs)
  print(prediction)

  if encoder.classes_[np.argmax(prediction)]==4:
    return "Positive"
  else:
    return "Negative"
  #print('Tweet is', 'positive' if encoder.classes_[np.argmax(prediction)]==4 else 'negative')

# aa = handler()
# print(aa)

#     print("In function fucker")
#     # s3_client = boto3.client('s3')
#     # s3_clientobj = s3_client.get_object(Bucket='tp-data-bucket', Key='tp-data.txt')

#     # for line in s3_clientobj['Body'].iter_lines():
#     #     object = json.loads(line)
#     #     print(f"Name: {object['name']['s']} ID: {object['id']['n']}")
#     print("Welcome to TechPrimers")
#     print("Lambda execution Completed...!")

#print(encoder.classes_)










